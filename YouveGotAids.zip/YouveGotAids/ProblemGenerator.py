import copy
import math
import random
from numpy.random import choice

class ProblemGenerator:

    def __init__(self, student):
        self.student = student
        self.operators = copy.deepcopy(student.getOperators())
        self.calculateOperatorProportion()

    def calculateOperatorProportion(self):
        totalPercentage = 0
        for op in self.operators:
            correct, total = self.operators[op]['level']
            # Small percentage if all correct
            percentage = 0.000001 if total == 0 else (correct / float(total))
            self.operators[op]['level'] = self.operators[op]['level'] + [percentage]
            totalPercentage += 1 / percentage
        for op in self.operators:
            self.operators[op]['level'] = self.operators[op]['level'] + [((1 / self.operators[op]['level'][2]) / totalPercentage)]
        # self.operators[op]['level'] = self.operators[op]['level'] + [((1 / self.operators[op]['level']][2]) / totalPercentage)] for op in self.operators
        #.operators = {op: [self.operators[op]['level'][0], self.operators[op]['level'][1], self.operators[op]['level'][2], ((1 / self.operators[oper][2]) / totalPercentage)] for op in self.operators}

    def getCombinatedProblem(self, operator, problem, combinables):
        ops = []
        n = int(math.floor(self.operators[operator]['lastIncrement']/60))
        for i in range(n):
            operator = choice(self.operators.keys(), p=[values['level'][3] for values in self.operators.values()])
            c = random.randint(min_val, max_val)
            problem += operator + str(c)
            ops.append(operator)
        return problem, ops

    def getProblems(self, n):
        problems = []
        combinables = self.student.getCombinables()
        for i in range(n):
            # Get operator
            operator = choice(self.operators.keys(), p=[values['level'][3] for values in self.operators.values()])
            min_val = self.student.getMin(operator)
            max_val = self.student.getMax(operator)
            a = random.randint(min_val, max_val)
            b = random.randint(min_val, max_val)
            if a > b:
                problem = str(a) + operator + str(b)
            else:
                problem = str(b) + operator + str(a)
            ops = [operator]
            if operator in combinables and len(combinables)>1:
                problem, operators = self.getCombinatedProblem(operator, problem, combinables,n)
                ops += operators
            elif self.student.getCorrectness(operator)>80 and self.operators[operator]['lastIncrement']%60==0:
                m = int(math.floor(self.operators[operator]['lastIncrement']/60))
                for j in range(m):
                    c = random.randint(min_val, max_val)
                    problem += operator + str(c)
            problems.append((problem, ops))
        return problems
