import pickle
import AnswerRecognition
from Student import Student
from ProblemGenerator import ProblemGenerator

def loadDatabase():
    try:
        database = pickle.load(open("StudentDatabase.pkl", "rb" ))
    except EOFError:
        database = {}
    return database

def storeDatabase(database):
    pickle.dump(database,open("StudentDatabase.pkl", "wb"))

def getStudent():
    database = loadDatabase()
    studentID = raw_input('Enter your student-ID: ')
    if not studentID in database:
        studentName = raw_input('Enter your name: ')
        database[studentID] = Student(studentName, studentID)
        storeDatabase(database)
    student = database[studentID]
    return student

def getPersonalProblems(student):
    pg = ProblemGenerator(student)
    n = int(raw_input('Enter number of problems to be solved: '))
    problems = pg.getProblems(n)
    return problems

def checkAnswers(student, problems):
    # with open('wordToNumDict.pickle', 'rb') as handle:
    #     w2n = pickle.load(handle)
    for p in problems:
        problem = p[0]
        operators = p[1]
        print(problem)
        correctAnswer = eval(problem)
        givenAnswer = raw_input('What is your answer?: ')
        # givenAnswer = AnswerRecognition.correct(correctAnswer, w2n, 2)
        for operator in operators:
            student.updateOperators(operator, int(givenAnswer)==correctAnswer)
            print(int(givenAnswer)==correctAnswer)
            student.updateIncrement(operator)

def updateRanges(student):
    # TODO: niet elke keer updaten als geen vragen meer geweest zijn
    for op in student.getOperators():
        increment = student.getLastIncrement(op)
        if student.getCorrectness(op)>=0.8 and increment%20==0 and increment%40!=0 and increment %60 !=0:
            student.incrementMax(op, 10)


def initNewOperator(student):
    operators = student.getOperators()
    if '/' in operators:
        return
    elif '*' in operators  and student.getCorrectness('*')>=0.8  and operators['*']['lastIncrement']>=40:
        if '/' not in operators:
            student.initialiseOperator('/')
    elif '-' in operators and student.getCorrectness('-')>=0.8  and operators['-']['lastIncrement']>=40:
        if '*' not in operators:
            student.initialiseOperator('*')
    elif student.getCorrectness('+')>=0.8  and operators['+']['lastIncrement']>=40:
        if '-' not in operators:
            student.initialiseOperator('-')


def saveStudent(student):
    database = loadDatabase()
    studentID = student.getID()
    database[studentID] = student
    storeDatabase(database)

if __name__== '__main__':
    student = getStudent()
    print(student.getOperators())
    problems = getPersonalProblems(student)
    checkAnswers(student, problems)
    updateRanges(student)
    initNewOperator(student)
    saveStudent(student)
    print(student.getOperators())
